/**
 * GENERATED FILE — do not edit.
 *
 * Source: src/client.tsx
 * Build:  npm run build   (Vite, then tools/wrap-client.mjs)
 */
window.__ModuleLoader__.load({
  id: "@harrywan/dsh-digital-human",
  factory(require) {
    const module = { exports: {} }
    const exports = module.exports
    ;(function (module, exports, require) {
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
//#region \0rolldown/runtime.js
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
//#endregion
let react = require("react");
react = __toESM(react, 1);
let _deepseek_ai_dsh_client_ui_primitives = require("@deepseek-ai/dsh-client-ui-primitives");
let react_jsx_runtime = require("react/jsx-runtime");
//#region src/client.tsx
/**
* Browser half of the digital-human platform — JSX source.
*
* Two columns: the left is the registry list, the right is the selected record.
* The settings page and the sidebar panel render this one component, so there is
* a single editing surface. Data arrives from the Host half over the Connection
* service's `/api` channel.
*
* Built by Vite into `client.js`. See `vite.config.mjs` and
* `tools/wrap-client.mjs`. Do not edit `client.js` by hand.
*/
/** Connection endpoint that carries this page's Host methods. */
var RPC_ENDPOINT = "digital-human";
/** Slot id of the sidebar panel. */
var PANEL_ID = "digital-humans";
/**
* Page stylesheet, injected once.
*
* A stylesheet is required rather than inline styles: hover, focus, and
* descendant states have no inline equivalent.
*/
var STYLE = `
.dh-root { display: flex; flex-direction: column; gap: 14px; min-width: 0; flex: 1 1 auto; }
.dh-panel { display: flex; flex-direction: column; gap: 12px; padding: 16px; overflow: auto; height: 100%; box-sizing: border-box; }
.dh-head { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.dh-title { font-size: 15px; line-height: 22px; color: var(--dsw-alias-label-primary); margin: 0; font-weight: 600; }
.dh-meta { font-size: 11px; line-height: 16px; color: var(--dsw-alias-label-tertiary); font-family: ui-monospace, monospace; overflow-wrap: anywhere; margin: 0; }
.dh-columns { display: flex; align-items: stretch; min-height: 0; flex: 1 1 auto; flex-wrap: wrap; }
.dh-listpane { display: flex; flex-direction: column; gap: 2px; flex: 0 0 220px; min-width: 180px; padding-right: 14px; border-right: 1px solid var(--dsw-alias-border-l1); }
.dh-detail { display: flex; flex-direction: column; gap: 18px; flex: 1 1 320px; min-width: 260px; padding-left: 14px; }
.dh-list { display: flex; flex-direction: column; gap: 1px; }
.dh-item {
  display: flex; flex-direction: column; gap: 1px; width: 100%;
  text-align: left; padding: 7px 9px; border: 0; border-radius: var(--dsw-radius-md, 8px);
  background: transparent; color: var(--dsw-alias-label-primary);
  font: inherit; cursor: pointer;
}
.dh-item:hover { background: var(--dsw-alias-interactive-bg-hover); }
.dh-item[data-active="true"] { background: var(--dsw-alias-interactive-bg-hover); }
.dh-item:focus-visible { outline: var(--dsw-focus-ring-width, 2px) solid var(--dsw-alias-state-business-primary); outline-offset: 1px; }
.dh-item-name { font-size: 14px; line-height: 20px; display: flex; align-items: center; gap: 6px; }
.dh-item-id { font-size: 11px; line-height: 15px; color: var(--dsw-alias-label-tertiary); font-family: ui-monospace, monospace; }
.dh-item-off .dh-item-name, .dh-item-name[data-off="true"] { color: var(--dsw-alias-label-tertiary); }
.dh-section {
  display: flex; flex-direction: column; gap: 10px;
  padding: 12px 14px; border-radius: var(--dsw-radius-lg, 10px);
  /* A second level: a record's own settings, not another row of the page. */
  border: 1px solid var(--dsw-alias-border-l2);
  background: var(--dsw-alias-bg-layer-1);
}
.dh-section-title { font-size: 14px; line-height: 20px; color: var(--dsw-alias-label-primary); margin: 0; font-weight: 600; }
.dh-field { display: flex; flex-direction: column; gap: 6px; }
/* A field name is a heading for its control, so it carries the primary label
   colour and a medium weight. It used to sit one step from the hint in both size
   and colour, which made a name and its explanation read as the same kind of
   text. */
.dh-label { font-size: 13px; line-height: 18px; color: var(--dsw-alias-label-primary); font-weight: 500; }
/* One field per group, separated by a rule: the page is a long list of unrelated
   controls, and spacing alone did not say where one ended. */
/* Every block is separated the same way, except a card, which carries its own
   border. Matching only the plain field blocks left the pickers and the switches
   without a rule, so some boundaries showed a line and some did not. */
/* Every block is separated by the same rule, cards included. Excluding them left
   their boundary to the card's own box border, so the one place the eye most wants
   a separator — under the large blocks — was the one place it was not drawn. */
/* Match the library Input wrapper exactly, so a multi-line field and a
   single-line one read as the same control. */
.dh-area {
  box-sizing: border-box; width: 100%; min-height: 130px; padding: 6px 8px;
  border: 0.5px solid var(--dsw-alias-border-l4);
  border-radius: var(--dsw-radius-md);
  background: var(--dsw-alias-bg-layer-1);
  color: var(--dsw-alias-label-primary);
  font-size: 14px; line-height: 22px; font-family: inherit;
  resize: vertical;
}
.dh-area:focus-visible { outline: none; border-color: var(--dsw-alias-state-business-primary); }
/* Button renders its icon before the children; reversing puts the chevron on
   the right, where a picker keeps it. */
.dh-trigger { width: 100%; flex-direction: row-reverse; justify-content: space-between; }
.dh-trigger-text { flex: 1 1 auto; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; text-align: left; }
/* The card is sized to the anchor by default; full labels need their own width. */
.dh-menu { min-width: 380px; max-width: min(760px, 92vw); }
.dh-menu [role="menuitem"] { font-size: 14px; }
.dh-choices { display: flex; flex-direction: column; gap: 4px; }
/* A repeatable name/value pair. The Input primitive puts className on its
   wrapper span and style on the native input, so the wrapper takes the width and
   the input fills it — the same split Field relies on. No backticks in here: this
   block is a template literal, and one would end it. */
.dh-rows { display: flex; flex-direction: column; gap: 6px; }
.dh-row { display: flex; gap: 6px; align-items: center; }
.dh-row-name { flex: 0 0 34%; min-width: 0; }
.dh-row-value { flex: 1 1 auto; min-width: 0; }
.dh-row-name input, .dh-row-value input { width: 100%; }
.dh-row-remove { flex: 0 0 auto; }
.dh-actions { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
.dh-error { font-size: 12px; line-height: 18px; color: var(--dsw-alias-state-error-primary); margin: 0; }
.dh-notice { font-size: 12px; line-height: 18px; color: var(--dsw-alias-state-business-primary); margin: 0; }
.dh-hint { font-size: 12px; line-height: 17px; color: var(--dsw-alias-label-tertiary); margin: 0; }
/* A read-only value is content, not chrome: it keeps body size and weight. */
.dh-hint code { font-family: ui-monospace, monospace; font-size: 12px; }
.dh-empty { font-size: 13px; line-height: 19px; color: var(--dsw-alias-label-secondary); padding: 6px 0; margin: 0; }
.dh-warn {
  font-size: 13px; line-height: 19px; color: var(--dsw-alias-label-primary);
  padding: 8px 10px; margin: 0; border-radius: var(--dsw-radius-md, 8px);
  border: 1px solid var(--dsw-alias-border-l2, var(--dsw-alias-border-l1));
  background: var(--dsw-alias-bg-layer-1);
}
.dh-readonly { font-size: 14px; line-height: 22px; color: var(--dsw-alias-label-primary); font-weight: 500; }
.dh-readonly code { font-family: ui-monospace, monospace; font-size: 13px; }
`;
var styleInjected = false;
/** Inject the stylesheet once per document. */
function ensureStyle() {
	if (styleInjected || typeof document === "undefined") return;
	styleInjected = true;
	const element = document.createElement("style");
	element.setAttribute("data-digital-human", "styles");
	element.textContent = STYLE;
	document.head.appendChild(element);
}
/** Explain how a bound bot's Workspace relates to the digital human's. */
function botWorkspaceNote(bot, workspace) {
	if (!bot) return "别名在「设置 → IM机器人」里设置；没设别名时按绑定的工作区区分。";
	if (!workspace) return "数字人还没选工作区。不选就在「数字人」工作区里跑。";
	if (!bot.workspace) return `这个 bot 还没有工作区。去「设置 → IM机器人」把它设为 ${workspace}。`;
	if (bot.workspace !== workspace) return `bot 的工作区是 ${bot.workspace}，与数字人的 ${workspace} 不同。以数字人为准 —— 去「设置 → IM机器人」把 bot 改成 ${workspace}。`;
	return `已对齐：数字人和 bot 都在 ${workspace} 里跑。`;
}
/**
* Fold the edited rows back into the config map.
*
* A half-typed row is dropped rather than stored: the store treats an empty
* value as "not configured", and a row with no name has nothing to key on.
*/
function configFromRows(rows) {
	const out = {};
	for (const row of rows ?? []) {
		const name = row.name.trim();
		const value = row.value.trim();
		if (name && value) out[name] = value;
	}
	return out;
}
/**
* The declared config fields, one control per field.
*
* The record's schema decides the control and whether the operator may type at
* all: a field the platform already knows — the bot's own name, the owner's
* address — is shown read-only, because there is nothing to fill in.
*
* Every control holds what the operator set, and nothing else. The effective value
* is the Host's to resolve, and it is deliberately not echoed here: this page
* edits choices, so showing a resolved value next to an empty input invites the
* operator to read a default as something they chose.
*/
function SchemaFields({ schema, rows, onChange }) {
	const valueOf = (key) => rows.find((row) => row.name === key)?.value ?? "";
	const setValue = (key, value) => {
		const at = rows.findIndex((row) => row.name === key);
		if (at === -1) {
			if (value) onChange([...rows, {
				name: key,
				value
			}]);
			return;
		}
		onChange(rows.map((row, index) => index === at ? {
			...row,
			value
		} : row));
	};
	const shown = schema.filter((field) => field.hidden !== true);
	const declared = new Set(schema.map((field) => field.key));
	const undeclared = rows.filter((row) => row.name !== "" && !declared.has(row.name));
	return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
		className: "dh-section",
		children: [
			/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
				className: "dh-section-title",
				children: "配置"
			}),
			shown.map((field) => {
				const label = field.label || field.key;
				if (field.from) return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: "dh-field",
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						className: "dh-label",
						children: label
					}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
						className: "dh-hint",
						children: ["平台自动提供，不用填。", field.description ?? ""]
					})]
				}, field.key);
				if (field.type === "boolean") return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Checkbox, {
					checked: valueOf(field.key) === "true",
					label,
					onChange: (next) => setValue(field.key, next ? "true" : "")
				}, field.key);
				if (field.type === "number") return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(Field, {
					label,
					value: valueOf(field.key),
					inputType: "number",
					hint: field.description,
					onChange: (next) => setValue(field.key, next)
				}, field.key);
				if (field.type === "select") return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(MenuField, {
					label,
					value: valueOf(field.key),
					options: [{
						id: "",
						label: "（未设置）"
					}, ...(field.options ?? []).map((option) => ({
						id: option.value,
						label: option.label
					}))],
					onChange: (next) => setValue(field.key, next),
					hint: field.description
				}, field.key);
				return /* @__PURE__ */ (0, react_jsx_runtime.jsx)(Field, {
					label,
					value: valueOf(field.key),
					onChange: (next) => setValue(field.key, next),
					hint: field.description
				}, field.key);
			}),
			undeclared.length > 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: "dh-field",
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						className: "dh-hint",
						children: "未声明"
					}),
					undeclared.map((row) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: "dh-row",
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: "dh-row-name",
								children: row.name
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: "dh-row-value",
								children: row.value
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
								variant: "ghost",
								size: "sm",
								"aria-label": `移除未声明的配置项 ${row.name}`,
								onClick: () => onChange(rows.filter((entry) => entry.name !== row.name)),
								children: "移除"
							})
						]
					}, `undeclared-${row.name}`)),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						className: "dh-hint",
						children: "这些键不在记录的声明里，宿主解析时会忽略它们；保存仍会原样带回，所以留在这里可以移除。"
					})
				]
			}) : null
		]
	});
}
/**
* One labelled repeatable name/value editor.
*
* A persona names its own config keys, so the form has no schema to lay out —
* the operator adds the pairs the persona asks for. This replaces a plain
* textarea: a `name=value` line is easy to mistype and gives no feedback about
* which half is missing.
*/
function ConfigField({ rows, onChange, hint }) {
	const setAt = (index, patch) => {
		onChange(rows.map((row, at) => at === index ? {
			...row,
			...patch
		} : row));
	};
	return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
		className: "dh-section",
		children: [
			/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
				className: "dh-section-title",
				children: "配置"
			}),
			rows.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
				className: "dh-empty",
				children: "还没有配置项。未配置的项由宿主按人设自己的规则处理。"
			}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
				className: "dh-rows",
				children: rows.map((row, index) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: "dh-row",
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Input, {
							className: "dh-row-name",
							placeholder: "名称",
							value: row.name,
							onChange: (event) => setAt(index, { name: event.target.value })
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Input, {
							className: "dh-row-value",
							placeholder: "值",
							value: row.value,
							onChange: (event) => setAt(index, { value: event.target.value })
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
							className: "dh-row-remove",
							variant: "ghost",
							size: "sm",
							"aria-label": `删除配置项 ${index + 1}`,
							onClick: () => onChange(rows.filter((_, at) => at !== index)),
							children: "删除"
						})
					]
				}, index))
			}),
			/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
				className: "dh-actions",
				children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
					variant: "outline",
					size: "sm",
					onClick: () => onChange([...rows, {
						name: "",
						value: ""
					}]),
					children: "添加一项"
				})
			}),
			hint ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
				className: "dh-hint",
				children: hint
			}) : null
		]
	});
}
/**
* The owner is claimed, never typed, so this page only reports it.
*
* The WeCom channel sends no display name, so the claimed value is an opaque
* sender id — which is exactly why the field is read-only: nobody could type it.
*/
/** Name a bot for a trigger: alias first, then the raw id. Never the path. */
function botShortLabel(bot) {
	return `${bot.channel ? `${bot.channel} · ` : ""}${bot.alias || bot.botId}`;
}
/** Name a bot for a picker: alias first, then its directory, then the raw id. */
function botLabel(bot) {
	const channel = bot.channel ? `${bot.channel} · ` : "";
	if (bot.alias) return `${channel}${bot.alias} — ${bot.botId}`;
	if (bot.workspace) return `${channel}${bot.botId} — ${bot.workspace}`;
	return `${channel}${bot.botId}`;
}
/** A new record's form state. */
var BLANK = {
	id: "",
	name: "",
	description: "",
	systemPrompt: "",
	config: [],
	workspace: "",
	skills: [],
	peers: [],
	botId: "",
	owner: "",
	permissionPreset: "",
	enabled: true,
	memory: true,
	creating: false
};
/** Form state for a stored record. */
function toDraft(human) {
	return {
		id: human.id,
		name: human.name,
		description: human.description ?? "",
		systemPrompt: human.systemPrompt ?? "",
		config: Object.entries(human.config ?? {}).map(([name, value]) => ({
			name,
			value
		})),
		workspace: human.workspace ?? "",
		skills: [...human.skills ?? []],
		peers: [...human.peers ?? []],
		botId: human.im?.botId ?? "",
		owner: human.im?.owner ?? "",
		permissionPreset: human.permissionPreset ?? "",
		enabled: human.enabled !== false,
		memory: human.memory !== false,
		creating: false
	};
}
/** The patch a save sends. */
function toPatch(draft) {
	return {
		name: draft.name.trim(),
		description: draft.description.trim(),
		systemPrompt: draft.systemPrompt,
		config: configFromRows(draft.config),
		workspace: draft.workspace.trim(),
		skills: draft.skills ?? [],
		peers: draft.peers ?? [],
		im: {
			botId: draft.botId.trim(),
			owner: draft.owner.trim()
		},
		permissionPreset: draft.permissionPreset,
		enabled: draft.enabled,
		memory: draft.memory
	};
}
/** One labelled single-line field. */
function Field({ label, value, onChange, hint, mono, disabled, inputType }) {
	return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", {
		className: "dh-field",
		children: [
			/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
				className: "dh-label",
				children: label
			}),
			/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Input, {
				style: {
					width: "100%",
					...mono ? { fontFamily: "ui-monospace, monospace" } : {}
				},
				value: value ?? "",
				disabled: disabled === true,
				type: inputType,
				onChange: (event) => onChange(event.target.value)
			}),
			hint ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
				className: "dh-hint",
				children: hint
			}) : null
		]
	});
}
/**
* One labelled picker, built from the library's anchored menu.
*
* The library ships no select atom; its settings pages open a `Menu` from a
* button trigger, so this does the same and keeps the page's keyboard walk.
*/
function MenuField({ label, value, options, onChange, hint, placeholder }) {
	const [open, setOpen] = react.default.useState(false);
	const current = options.find((option) => option.id === value);
	const outside = value !== "" && !current ? value : void 0;
	return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
		className: "dh-field",
		children: [
			/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
				className: "dh-label",
				children: label
			}),
			/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Menu, {
				open,
				onClose: () => setOpen(false),
				selectedId: value,
				align: "start",
				side: "bottom",
				listClassName: "dh-menu",
				portal: true,
				items: options.map((option) => ({
					id: option.id,
					label: option.label
				})),
				onSelect: (id) => {
					onChange(id);
					setOpen(false);
				},
				anchor: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
					variant: "outline",
					className: "dh-trigger",
					onClick: () => setOpen((wasOpen) => !wasOpen),
					icon: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.IconChevronDownOutlineRegular, {}),
					children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						className: "dh-trigger-text",
						children: current ? current.short ?? current.label : outside ? `${outside}（不在选项中）` : placeholder ?? "请选择"
					})
				})
			}),
			hint ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
				className: "dh-hint",
				children: hint
			}) : null
		]
	});
}
/**
* Derive a skill name from the files being uploaded.
*
* The frontmatter is authoritative — it is the name the model will address — and a
* directory or file name is only the fallback for a skill that declares none.
*/
function skillNameOf(files, folder) {
	const entry = Object.keys(files).find((path) => path.split("/").pop()?.toLowerCase() === "skill.md");
	const text = entry ? files[entry] : "";
	const declared = /^name\s*:\s*(.+)$/m.exec(String(text).split("---")[1] ?? "")?.[1]?.trim();
	if (declared) return declared.replace(/^["']|["']$/g, "").slice(0, 64);
	const first = Object.keys(files)[0] ?? "";
	return (folder || first.split("/")[0]?.replace(/\.md$/i, "") || "skill").replace(/[^A-Za-z0-9._-]/g, "-").slice(0, 64);
}
/** The configuration page: list on the left, the selected record on the right. */
function DigitalHumansPage({ rpc }) {
	const [phase, setPhase] = react.default.useState("loading");
	const [humans, setHumans] = react.default.useState([]);
	const [file, setFile] = react.default.useState("");
	const [draft, setDraft] = react.default.useState(null);
	const [bots, setBots] = react.default.useState([]);
	const [sideErrors, setSideErrors] = react.default.useState({});
	const [permissionChoices, setPermissionChoices] = react.default.useState([]);
	/** Whether the delete button has been armed by a first click. */
	const [confirmingDelete, setConfirmingDelete] = react.default.useState(false);
	const [skills, setSkills] = react.default.useState([]);
	const [library, setLibrary] = react.default.useState([]);
	const uploadRef = react.default.useRef(null);
	const importRef = react.default.useRef(null);
	const [workspaces, setWorkspaces] = react.default.useState({
		items: [],
		defaultTitle: "数字人",
		defaultPath: null
	});
	const [error, setError] = react.default.useState(null);
	const [notice, setNotice] = react.default.useState(null);
	const [busy, setBusy] = react.default.useState(false);
	const mounted = react.default.useRef(true);
	react.default.useEffect(() => {
		mounted.current = true;
		return () => {
			mounted.current = false;
		};
	}, []);
	react.default.useEffect(() => {
		ensureStyle();
	}, []);
	/** Call one Host method, unwrapping the Connection envelope. */
	const call = react.default.useCallback(async (method, payload = {}, signal) => {
		const result = await rpc(method, payload, signal);
		if (result?.ok !== true) throw new Error(result?.error?.message ?? "宿主拒绝了这次请求");
		return result.value;
	}, [rpc]);
	const load = react.default.useCallback(async (signal) => {
		const value = await call("registry.list", {}, signal);
		if (signal?.aborted || !mounted.current) return;
		setHumans(value.humans);
		setFile(value.file);
		setDraft((current) => {
			if (current?.creating === true) return current;
			if (current) {
				const fresh = value.humans.find((entry) => entry.id === current.id);
				if (fresh) return toDraft(fresh);
			}
			return value.humans.length > 0 ? toDraft(value.humans[0]) : {
				...BLANK,
				creating: true
			};
		});
		setPhase("ready");
	}, [call]);
	react.default.useEffect(() => {
		const controller = new AbortController();
		load(controller.signal).catch((caught) => {
			if (controller.signal.aborted || caught?.name === "AbortError") return;
			setError(String(caught.message ?? caught));
			setPhase("ready");
		});
		return () => controller.abort();
	}, [load]);
	react.default.useEffect(() => {
		const controller = new AbortController();
		call("im.bots", {}, controller.signal).then((value) => {
			if (!controller.signal.aborted && mounted.current) setBots(Array.isArray(value?.bots) ? value.bots : []);
		}).catch((caught) => {
			if (controller.signal.aborted || !mounted.current) return;
			setSideErrors((current) => ({
				...current,
				bots: String(caught?.message ?? caught)
			}));
		});
		return () => controller.abort();
	}, [call]);
	react.default.useEffect(() => {
		const controller = new AbortController();
		call("workspaces.list", {}, controller.signal).then((value) => {
			if (controller.signal.aborted || !mounted.current) return;
			setWorkspaces({
				items: Array.isArray(value?.workspaces) ? value.workspaces : [],
				defaultTitle: value?.defaultTitle ?? "数字人",
				defaultPath: value?.defaultPath ?? null
			});
		}).catch((caught) => {
			if (controller.signal.aborted || !mounted.current) return;
			setSideErrors((current) => ({
				...current,
				workspaces: String(caught?.message ?? caught)
			}));
		});
		return () => controller.abort();
	}, [call]);
	react.default.useEffect(() => {
		const controller = new AbortController();
		call("skills.library", {}, controller.signal).then((value) => {
			if (controller.signal.aborted || !mounted.current) return;
			setLibrary(Array.isArray(value?.skills) ? value.skills : []);
		}).catch((caught) => {
			if (controller.signal.aborted || !mounted.current) return;
			setSideErrors((current) => ({
				...current,
				library: String(caught?.message ?? caught)
			}));
		});
		return () => controller.abort();
	}, [call]);
	react.default.useEffect(() => {
		const controller = new AbortController();
		call("permissions.list", {}, controller.signal).then((value) => {
			if (controller.signal.aborted || !mounted.current) return;
			setPermissionChoices(Array.isArray(value?.presets) ? value.presets : []);
		}).catch(() => {});
		return () => controller.abort();
	}, [call]);
	react.default.useEffect(() => {
		const controller = new AbortController();
		call("skills.list", {}, controller.signal).then((value) => {
			if (!controller.signal.aborted && mounted.current) setSkills(Array.isArray(value?.skills) ? value.skills : []);
		}).catch((caught) => {
			if (controller.signal.aborted || !mounted.current) return;
			setSideErrors((current) => ({
				...current,
				skills: String(caught?.message ?? caught)
			}));
		});
		return () => controller.abort();
	}, [call]);
	/** Run one mutation, then refresh from the Host. */
	const act = async (work) => {
		setBusy(true);
		setError(null);
		setNotice(null);
		try {
			const message = await work();
			await load();
			if (mounted.current) setNotice(message);
		} catch (caught) {
			if (mounted.current) setError(String(caught.message ?? caught));
		} finally {
			if (mounted.current) setBusy(false);
		}
	};
	const patch = (fields) => setDraft((current) => current ? {
		...current,
		...fields
	} : current);
	/** Reload the plugin's skill space after changing it. */
	const reloadLibrary = async () => {
		const value = await call("skills.library", {});
		if (mounted.current) setLibrary(Array.isArray(value?.skills) ? value.skills : []);
	};
	/**
	* Upload the picked files as one skill.
	*
	* A directory pick keeps its relative paths, so references travel with the body;
	* the first path segment is the folder the operator chose, which is not part of
	* the skill. A skill whose files cannot be read as text is refused by the Host,
	* because a binary resource would arrive as mojibake rather than as itself.
	*/
	const uploadSkills = async (picked) => {
		const files = [...picked ?? []];
		if (files.length === 0) return;
		await act(async () => {
			const contents = {};
			let folder;
			for (const file of files) {
				const relative = (file.webkitRelativePath || file.name).split("/");
				if (relative.length > 1) folder = folder ?? relative[0];
				const path = (relative.length > 1 ? relative.slice(1) : relative).join("/");
				contents[path] = await file.text();
			}
			const name = skillNameOf(contents, folder);
			await call("skills.upload", {
				name,
				files: contents
			});
			await reloadLibrary();
			return `已上传技能 ${name}（${files.length} 个文件）`;
		});
		if (uploadRef.current) uploadRef.current.value = "";
	};
	/**
	* Download one digital human as a bundle.
	*
	* A plain navigation, so the browser saves the file itself: routing a package
	* through the JSON channel would base64 it and hold it twice, and a skill set can
	* be tens of megabytes.
	*/
	const exportHuman = () => {
		const id = (draft?.id ?? "").trim();
		if (!id) return;
		const memory = draft?.memory === false ? "" : "?memory=1";
		window.open(`/api/digital-human/bundle/${encodeURIComponent(id)}${memory}`, "_blank");
	};
	/** Read one bundle into the registry. */
	const importHuman = async (picked) => {
		const file = [...picked ?? []][0];
		if (!file) return;
		await act(async () => {
			const answer = await (await fetch("/api/digital-human/bundle", {
				method: "POST",
				credentials: "same-origin",
				body: file
			})).json().catch(() => void 0);
			if (answer?.ok !== true) throw new Error(answer?.error?.message ?? "导入失败：宿主没有返回可读的结果");
			const value = answer.value ?? {};
			return `已导入 ${value.id}（技能 ${value.skills?.length ?? 0} 个${value.memory ? "，含记忆" : ""}）`;
		});
		if (importRef.current) importRef.current.value = "";
	};
	/** Remove one skill from the plugin's skill space. */
	const removeLibrarySkill = async (name) => {
		await act(async () => {
			await call("skills.remove", { name });
			await reloadLibrary();
			if ((draft?.skills ?? []).includes(name)) patch({ skills: (draft?.skills ?? []).filter((entry) => entry !== name) });
			return `已删除技能 ${name}`;
		});
	};
	if (phase === "loading") return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
		className: "dh-root",
		children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
			className: "dh-hint",
			children: "正在读取数字人注册表…"
		})
	});
	const creating = draft?.creating === true;
	const peers = draft?.peers ?? [];
	const others = humans.filter((entry) => entry.id !== draft?.id);
	const chosen = draft?.skills ?? [];
	const catalog = skills.map((entry) => entry.name);
	[...skills, ...chosen.filter((name) => !catalog.includes(name)).map((name) => ({
		name,
		description: "这个技能当前不在目录里。"
	}))];
	const selected = humans.find((entry) => entry.id === draft?.id);
	const selectedSchema = selected?.configSchema ?? [];
	const selectedPresetId = selected?.presetId ?? "";
	const failedAlignment = (selected?.alignment ?? []).filter((entry) => entry.ok !== true);
	const boundBot = bots.find((entry) => entry.botId === draft?.botId);
	return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
		className: "dh-root",
		children: [
			/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: "dh-head",
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("h3", {
						className: "dh-title",
						children: [
							"数字人（",
							humans.length,
							"）"
						]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
						size: "sm",
						style: { marginLeft: "auto" },
						disabled: busy,
						onClick: () => {
							setNotice(null);
							setError(null);
							setConfirmingDelete(false);
							setDraft({
								...BLANK,
								creating: true
							});
						},
						children: "新建"
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
						size: "sm",
						disabled: busy,
						onClick: () => act(async () => {
							await load();
							return "已刷新";
						}),
						children: "刷新"
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
						variant: "outline",
						size: "sm",
						disabled: busy || !(draft?.id ?? "").trim(),
						onClick: exportHuman,
						children: "导出"
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
						ref: importRef,
						type: "file",
						accept: ".gz,.tgz,application/gzip",
						style: { display: "none" },
						onChange: (event) => {
							importHuman(event.target.files);
						}
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
						variant: "outline",
						size: "sm",
						disabled: busy,
						onClick: () => importRef.current?.click(),
						children: "导入"
					})
				]
			}),
			file ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", {
				className: "dh-meta",
				children: ["注册表：", file]
			}) : null,
			error ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
				className: "dh-error",
				role: "alert",
				children: error
			}) : null,
			notice ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
				className: "dh-notice",
				children: notice
			}) : null,
			/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				className: "dh-columns",
				children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: "dh-listpane",
					children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: "dh-list",
						children: [humans.map((entry) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "dh-item",
							"data-active": draft?.id === entry.id && !creating ? "true" : "false",
							onClick: () => {
								setNotice(null);
								setError(null);
								setConfirmingDelete(false);
								setDraft(toDraft(entry));
							},
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
								className: "dh-item-name",
								"data-off": entry.enabled ? "false" : "true",
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.StateDot, { state: entry.enabled ? "done" : "idle" }),
									entry.name,
									entry.enabled ? "" : "（已停用）"
								]
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: "dh-item-id",
								children: entry.id
							})]
						}, entry.id)), creating ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "dh-item",
							"data-active": "true",
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: "dh-item-name",
								children: "新建数字人"
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: "dh-item-id",
								children: "未保存"
							})]
						}) : null]
					}), humans.length === 0 && !creating ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: "dh-empty",
						children: "还没有数字人。"
					}) : null]
				}), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					className: "dh-detail",
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Field, {
							label: "ID",
							value: draft?.id,
							mono: true,
							disabled: !creating,
							onChange: (value) => patch({ id: value })
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Field, {
							label: "显示名称",
							value: draft?.name,
							onChange: (value) => patch({ name: value })
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(Field, {
							label: "一句话说明",
							value: draft?.description,
							onChange: (value) => patch({ description: value })
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", {
							className: "dh-field",
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: "dh-label",
								children: "人设"
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("textarea", {
								className: "dh-area",
								value: draft?.systemPrompt ?? "",
								onChange: (event) => patch({ systemPrompt: event.target.value })
							})]
						}),
						selectedSchema.length > 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(SchemaFields, {
							schema: selectedSchema,
							rows: draft?.config ?? [],
							onChange: (rows) => patch({ config: rows })
						}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(ConfigField, {
							rows: draft?.config ?? [],
							onChange: (rows) => patch({ config: rows }),
							hint: "人设里写 {{名称}} 会被替换成这里的值，实际值同时注入提示词。这条记录还没有声明字段，所以按名称/值手填。"
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(MenuField, {
							label: "工作区",
							value: draft?.workspace ?? "",
							options: [{
								id: "",
								label: `（默认：${workspaces.defaultTitle}）`
							}, ...(workspaces.items ?? []).map((item) => ({
								id: item.path,
								label: item.title || item.path
							}))],
							onChange: (value) => patch({ workspace: value }),
							hint: sideErrors.workspaces ? `工作区列表读取失败：${sideErrors.workspaces}${draft?.workspace ? `（这条记录仍在 ${draft.workspace} 里跑）` : ""}` : draft?.workspace ? `会话在 ${draft.workspace} 里跑。` : `不选就在「${workspaces.defaultTitle}」工作区里跑。`
						}, `workspace-${draft?.id ?? "new"}`),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: "dh-section",
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: "dh-section-title",
									children: "技能"
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
									ref: uploadRef,
									type: "file",
									"aria-label": "选择技能文件",
									multiple: true,
									webkitdirectory: "true",
									style: { display: "none" },
									onChange: (event) => {
										uploadSkills(event.target.files);
									}
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: "dh-actions",
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
										variant: "outline",
										size: "sm",
										disabled: busy,
										onClick: () => uploadRef.current?.click(),
										children: "上传技能"
									}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: "dh-hint",
										children: "放进插件技能空间，只有本数字人勾选后才加载；只收文本文件。"
									})]
								}),
								library.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
									className: "dh-empty",
									children: sideErrors.library ? `技能空间读取失败：${sideErrors.library}` : "技能空间是空的。上传一个技能，再勾选启用。"
								}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
									className: "dh-choices",
									children: library.map((entry) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
										className: "dh-row",
										children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Checkbox, {
											checked: chosen.includes(entry.name),
											label: `${entry.name}（${entry.files.length} 个文件）`,
											title: entry.description || entry.name,
											onChange: (next) => patch({ skills: next ? [...chosen, entry.name] : chosen.filter((name) => name !== entry.name) })
										}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
											variant: "ghost",
											size: "sm",
											"aria-label": `移除技能 ${entry.name}`,
											disabled: busy,
											onClick: () => {
												removeLibrarySkill(entry.name);
											},
											children: "移除"
										})]
									}, entry.name))
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: "dh-hint",
									children: sideErrors.skills ? `技能目录读取失败：${sideErrors.skills}` : "全局、项目与内置技能对所有数字人默认加载，不用勾选；只有这个技能空间里的，才需要按数字人勾选。"
								}),
								!sideErrors.library && chosen.some((name) => !library.some((entry) => entry.name === name)) ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: "dh-hint",
									children: `已勾选但技能空间里没有的：${chosen.filter((name) => !library.some((entry) => entry.name === name)).join("、")}。这些不会从技能空间加载 —— 上传它们，或者从勾选里去掉。`
								}) : null
							]
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: "dh-field",
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								className: "dh-label",
								children: "数字人间通讯"
							}), others.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
								className: "dh-empty",
								children: "还没有别的数字人可以联系。"
							}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: "dh-choices",
								children: others.map((entry) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Checkbox, {
									checked: peers.includes(entry.id),
									label: `${entry.name}（${entry.id}）`,
									onChange: (next) => patch({ peers: next ? [...peers, entry.id] : peers.filter((id) => id !== entry.id) })
								}, entry.id))
							})]
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(MenuField, {
							label: "IM bot",
							value: draft?.botId ?? "",
							options: [{
								id: "",
								label: "（不绑定）"
							}, ...bots.map((bot) => ({
								id: bot.botId,
								label: botLabel(bot),
								short: botShortLabel(bot)
							}))],
							onChange: (value) => patch({ botId: value }),
							hint: bots.length === 0 ? sideErrors.bots ? `bot 列表读取失败：${sideErrors.bots}` : "还没有 bot。去「设置 → IM机器人」选一个通道，扫码创建。" : botWorkspaceNote(boundBot, draft?.workspace)
						}, `bot-${draft?.id ?? "new"}`),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: "dh-field",
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: "dh-label",
									children: "负责人"
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: "dh-readonly",
									children: draft?.owner ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", { children: draft.owner }) : "还没认领 —— 第一个私聊该 bot 的人自动成为负责人。"
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									className: "dh-hint",
									children: "自动认领，不用填。通道不传显示名时，这里就是不透明的 senderId。"
								})
							]
						}),
						failedAlignment.length > 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
							className: "dh-warn",
							role: "status",
							children: `有 ${failedAlignment.length} 项没有推送到绑定的 bot：` + failedAlignment.map((entry) => `${entry.endpoint ?? "未知端点"}（${entry.reason ?? "未知原因"}）`).join("、") + "。bot 可能缺工作区、预设或来源块，重启或重新保存会再试一次。"
						}) : null,
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(MenuField, {
							label: "权限预设",
							value: draft?.permissionPreset ?? "",
							options: [{
								id: "",
								label: "平台默认"
							}, ...permissionChoices.map((choice) => ({
								id: choice.value,
								label: choice.description ? `${choice.label} —— ${choice.description}` : choice.label
							}))],
							onChange: (value) => patch({ permissionPreset: value }),
							hint: "只作用于这个数字人自己的会话。IM 里没有人工应答批准，所以后两项会让它卡住。"
						}, `permission-${draft?.id ?? "new"}`),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Checkbox, {
							checked: draft?.enabled !== false,
							label: "启用",
							onChange: (next) => patch({ enabled: next })
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Checkbox, {
							checked: draft?.memory !== false,
							label: "持久记忆",
							onChange: (next) => patch({ memory: next })
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: "dh-actions",
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "primary",
									disabled: busy || !(draft?.id ?? "").trim(),
									onClick: () => act(async () => {
										const current = draft;
										if (!current) return "没有可选的数字人";
										const value = await call("registry.save", {
											id: current.id.trim(),
											patch: toPatch(current),
											partial: !creating
										});
										const saved = {
											...value.human,
											presetId: value.presetId
										};
										setHumans((existing) => {
											const at = existing.findIndex((entry) => entry.id === saved.id);
											if (at === -1) return [...existing, saved];
											return existing.map((entry, index) => index === at ? saved : entry);
										});
										if (mounted.current) setDraft((existing) => existing ? {
											...existing,
											id: value.human.id,
											creating: false
										} : existing);
										return `已保存 ${value.human.name}（preset ${value.presetId}）`;
									}),
									children: creating ? "创建" : "保存"
								}),
								creating ? null : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Button, {
									variant: "outline",
									disabled: busy,
									onClick: () => {
										if (!confirmingDelete) {
											setConfirmingDelete(true);
											return;
										}
										act(async () => {
											const current = draft;
											if (!current) return "没有可选的数字人";
											await call("registry.remove", { id: current.id });
											if (mounted.current) {
												setHumans((existing) => existing.filter((entry) => entry.id !== current.id));
												setDraft(null);
											}
											return `已删除 ${current.id}`;
										});
									},
									children: confirmingDelete ? "确认删除" : "删除"
								}),
								creating ? null : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(_deepseek_ai_dsh_client_ui_primitives.Pill, { children: selectedPresetId ? `preset：${selectedPresetId}` : "preset：未注册" })
							]
						})
					]
				})]
			})
		]
	});
}
/** Sidebar icon for the panel. */
function DigitalHumansIcon({ size }) {
	return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		width: size,
		height: size,
		"aria-hidden": "true",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 1.6,
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ (0, react_jsx_runtime.jsx)("circle", {
				cx: 9,
				cy: 9,
				r: 3
			}),
			/* @__PURE__ */ (0, react_jsx_runtime.jsx)("circle", {
				cx: 16.5,
				cy: 15.5,
				r: 2.5
			}),
			/* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", { d: "M3.5 19.5c0-2.5 2.4-4.2 5.5-4.2s5.5 1.7 5.5 4.2" })
		]
	});
}
/** The main-column panel: the same page in a full-height container. */
function DigitalHumansPanel({ rpc }) {
	return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
		className: "dh-panel",
		children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(DigitalHumansPage, { rpc })
	});
}
var inject = ["slots", "connection"];
function apply(ctx) {
	/** One Host call, with transport failure kept distinct from a refused call. */
	const rpc = async (method, payload, signal) => {
		try {
			return await ctx.connection.rpc.call("/api", RPC_ENDPOINT, {
				method,
				payload
			}, signal);
		} catch (cause) {
			if (signal?.aborted || cause?.name === "AbortError") throw cause;
			throw new Error("无法访问 DSH 管理接口，请检查连接后重试。");
		}
	};
	ctx.effect(() => ctx.slots.inject("sidebar.panellist", () => {
		const dispose = ctx.slots.register({
			name: "sidebar.panellist",
			id: PANEL_ID,
			order: 20,
			label: () => "数字人"
		}, DigitalHumansIcon);
		return () => dispose();
	}), "digital-human: sidebar panel entry");
	ctx.effect(() => ctx.slots.inject("main", () => {
		const dispose = ctx.slots.register({
			name: "main",
			key: PANEL_ID,
			inject: () => ({ rpc })
		}, DigitalHumansPanel);
		return () => dispose();
	}), "digital-human: main panel");
}
//#endregion
exports.apply = apply;
exports.inject = inject;

    }).call(module.exports, module, module.exports, require)
    return module.exports
  },
})
